sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/m/MessageBox",
  "sap/m/PDFViewer",
  "sap/m/BusyDialog",
  "sap/m/MessageToast"
], (Controller, MessageBox, PDFViewer, BusyDialog, MessageToast) => {
  "use strict";

  return Controller.extend("treasuryui.controller.TreasuryMainView", {
    onInit() {
      let oModel = new sap.ui.model.json.JSONModel();
      // this.getView().setModel(oModel);
      this.getView().setModel(oModel, "treasuryModel");
    },
    onfetchCSRF: async function (url) {
      const response = await fetch(url, {
        method: "GET",
        headers: {
          "X-CSRF-Token": "Fetch"
        }
      });
      const token = response.headers.get("X-CSRF-Token");
      if (!token) {
        throw new Error("Failed to fetch CSRF token");
      }
      return token;
    },
    onSelectDocument: function (oEvent) {
      var oMultiBox = oEvent.getSource();
      var aSelectedItems = oMultiBox.getSelectedItems();
      var aFiles = aSelectedItems.map(function (element) {
        return "File: " + element.getText(); //or getKey, whatever holds the correct data
      });
      aFiles.push("Question: ");
      var sFormattedPrompt = aFiles.join("\n");
      this.byId("chatFeedInput").setValue(sFormattedPrompt);
    },

    onUserChat: async function () {
      const chatModel = this.getOwnerComponent().getModel("chatModel");
      const oView = this.getView();
      const sInput = this.byId("chatFeedInput").getValue();
      var aSelectedItems = this.byId("multiCombo").getSelectedItems();
      const isValid = sInput.toLowerCase().includes("intellibase") || aSelectedItems.length > 0;
      // Disable submit + hide previous result
      chatModel.setSubmit(false);
      chatModel.setvisibleResult(false);

      // Create and show busy dialog
      const oBusyDialog = new sap.m.BusyDialog({
        title: "Busy Indicator",
        text: "Generating response. Please standby.."
      });
      oBusyDialog.open();

      // Freeze the screen
      oView.setBusy(true);

      await Promise.resolve();

      try {
        const resp = await this.onfetchData(sInput, isValid);

        chatModel.setResult(resp);
        chatModel.setvisibleResult(true);
        console.log(resp);
        return resp;
      } catch (err) {
        console.error("Chat fetch error:", err);
        sap.m.MessageToast.show("Failed to get response.");
      } finally {
        oBusyDialog.close();
        oView.setBusy(false);
      }
    },

    onfetchData: async function (sInput, isValid) {
      const chatUrl = this.getBaseUrl() + "/api/chat";
      const csrf = this.fetchCsrfToken();
      const oContainer = this.byId("pdfContainer");
      oContainer.removeAllItems();
      const controller = new AbortController();
      const timeout = setTimeout(() => {
        controller.abort(); // Aborts the request after 90s
      }, 90000);

      // const url = "https://standard-chartered-bank-core-foundational-12982zqn-genai839893a.cfapps.ap11.hana.ondemand.com/api/chat";

      if (!isValid) {
        MessageBox.error("Please select a file or Ask Intellibase");
        return;
      }
      const payload = { "message": "user_id: 1623894:" + sInput };

      try {
        const response = await fetch(chatUrl, {
          method: "POST",
          headers: {
            "X-CSRF-Token": csrf,
            "Content-Type": "application/json"
          },
          body: JSON.stringify(payload),
          signal: controller.signal
        });
        clearTimeout(timeout);

        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const data = await response.json();
        const sResponse = data.FINAL_RESULT + "<h3>SQL Query Used:</h3>" +
          "<pre style='font-family: monospace; white-space: pre-wrap;'>" +
          data.SQL_QUERY + "</pre>";
        const oHtml = new sap.m.FormattedText({
          htmlText: sResponse
        });
        oContainer.addItem(oHtml);
        // oContainer.addItem(sResponseQuery);
        console.log("API Response:", sResponse);
        return oContainer;
      } catch (err) {
        console.log("inside catch of askFinsight", err);
      }

    },

    onGenerateSummary: async function (oEvent) {
      var aMultiBoxSelectedItems = this.byId("multiCombo").getSelectedItems();
      var textArea = this.byId("chatFeedInput");
      if (aMultiBoxSelectedItems.length > 1 || aMultiBoxSelectedItems.length == 0) {
        MessageBox.error("Please select a single file to Generate Summary.");
        return;
      }
      var oSelectedFile = aMultiBoxSelectedItems[0].getText(); // or .getKey() depending on your binding
      // MessageBox.success("Proceeding with file: ", oSelectedFile);
      textArea.setValue(`Research Summary: ${oSelectedFile}`)
      this._callSummaryApi("Research Summary: C-PressRelease-2Q25.pdf", oSelectedFile);
    },
    getBaseUrl: function () {
      return sap.ui.require.toUrl('treasuryui');
    },
    fetchCsrfToken: async function () {
      let url = this.getBaseUrl();
      const response = await fetch(url, {
        method: "HEAD",
        credentials: "include",
        headers: {
          "X-CSRF-Token": "Fetch"
        }
      })
      const token = response.headers.get("X-CSRF-Token");
      return token;
    },
    _callSummaryApi: async function (promptMessage, oSelectedFile) {
      const oBusy = new BusyDialog({ text: "Fetching summary..." });
      oBusy.open();
      // var url = "https://standard-chartered-bank-core-foundational-12982zqn-genai839893a.cfapps.ap11.hana.ondemand.com/api/chat"  
      const chatModel = this.getOwnerComponent().getModel("chatModel");
      const chatUrl = this.getBaseUrl() + "/api/chat";
      const csrf = this.fetchCsrfToken();
      const payload = {
        "message": "Research Summary: " + oSelectedFile
      };
      // // Disable submit + hide previous result
      chatModel.setSubmit(false);
      chatModel.setvisibleResult(false);
      // var url = sap.ui.require.toUrl('treasuryui') + "/user-api/currentUser";
      try {
        const response = await fetch(chatUrl, {
          method: "POST",
          headers: {
            "X-CSRF-Token": csrf,
            "Content-Type": "application/json"
          },
          body: JSON.stringify(payload)
        });

        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const json = await response.json();
        if (json.success && Array.isArray(json.summary_files)) {
          var res = this._displayPdfFiles(json.summary_files);
          oBusy.close();
          chatModel.setResult(res);
          chatModel.setvisibleResult(true);
          return res;
        } else {
          MessageToast.show("No summaries returned.");
        }
      } catch (err) {
        console.log("inside catch of generate summary", err);
      }
    },

    _displayPdfFiles: function (filesArray) {
      const oContainer = this.byId("pdfContainer");
      oContainer.removeAllItems();

      filesArray.forEach(file => {
        const oPdfViewer = this._createPdfViewer(file.data, file.filename);
        oContainer.addItem(oPdfViewer);
      });
      return oContainer;
    },

    _createPdfViewer: function (base64, filename) {
      const byteCharacters = atob(base64);
      const bytes = new Uint8Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        bytes[i] = byteCharacters.charCodeAt(i);
      }
      const blob = new Blob([bytes], { type: "application/pdf" });
      const url = URL.createObjectURL(blob);

      const downloadButton = new sap.m.Button({
        icon: "sap-icon://download",
        tooltip: "Download PDF",
        type: "Transparent",
        press: function () {
          const a = document.createElement("a");
          a.href = url;
          a.download = filename;
          a.click();
        }
      });

      return new sap.m.Panel({
        headerText: filename,
        width: "100%",
        height: "250vh",
        content: [
          downloadButton,
          new sap.ui.core.HTML({
            content: `<iframe src="${url}" class="pdf-iframe" style="width: 100%; height: 150vh;"></iframe>`
          })
        ],
        layoutData: new sap.m.FlexItemData({ growFactor: 1 })
      });
      // return new sap.m.PDFViewer({
      //   source: url,
      //   title: filename,
      //   width: "100%",
      //   height: "600px",
      //   showDownloadButton: true
      // });
    }
  });
});