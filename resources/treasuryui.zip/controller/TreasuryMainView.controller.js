sap.ui.define(["sap/ui/core/mvc/Controller"],e=>{"use strict";return e.extend("treasuryui.controller.TreasuryMainView",{onInit(){}})});
//# sourceMappingURL=TreasuryMainView.controller.js.map