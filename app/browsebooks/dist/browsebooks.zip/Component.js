sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("browsebooks.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map